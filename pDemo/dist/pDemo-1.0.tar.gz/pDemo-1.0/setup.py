from setuptools import setup
setup(name="pDemo",
      version="1.0",
      description="The Mean of two number is being calculated",
      author="Hoffen",
      packages=['pDemo'],
      install_requires=[])