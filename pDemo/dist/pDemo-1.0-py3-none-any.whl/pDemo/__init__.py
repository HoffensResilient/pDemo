import numpy as np

def mean(inpt):
    size =len(inpt)
    return np.sum(inpt)/size



